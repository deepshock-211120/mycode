[CmdletBinding()]
param (
    [Parameter(Mandatory = $true)]
    [string]
    $CommitComments
)

$Env:AWS_PROFILE = '998191560686-OAO'
$Template_Directory = 'D:\repo\awshomelab-templates\templates'
$FileType_Filter = '*.yaml'
Get-ChildItem $Template_Directory -Filter $FileType_Filter | 
Foreach-Object {
    $File = "file://" + "$Template_Directory\$_"
    "Checking....$File"
    $null = aws cloudformation validate-template --template-body $File 
}

$Env:AWS_PROFILE = 'deepshock'
$null = aws s3 cp --recursive D:\repo\awshomelab-templates\ s3://deepshock-s3-mgmt-01/awshomelab-templates

$Env:AWS_PROFILE = '998191560686-OAO'
$null = aws cloudformation validate-template --template-body file://D:\repo\onprem-deepshock-awshomelab-iac\templates\onprem.deepshock.awshomelab.yaml
Set-Location -Path D:\repo\onprem-deepshock-awshomelab-iac
git add -A
git commit -m "$CommitComments"
Write-Output "Please check if any error, commit if no error."