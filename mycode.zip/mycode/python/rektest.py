import boto3
from botocore.utils import LABEL_RE
import pprintpp


def detect_labels_local_file(photo):

    client = boto3.client('rekognition')

    with open(photo, 'rb') as image:
        response = client.detect_labels(Image={'Bytes': image.read()})

    expectedResult = [d for d in response['Labels'] if d['Confidence'] > 70]
    all_labels = [[d['Name'], d['Confidence']]
                  for d in response['Labels'] if d['Confidence'] > 70]

    for strname, fltconfidence in all_labels:
        print(strname)
        print(fltconfidence)

    # pprintpp.pprint()
    # print('Detected labels in ' + photo)
    # for label in response['Labels']:
    #     print(label['Name'] + ' : ' + str(label['Confidence']))

    # return len(response['Labels'])


def main():
    photo = 'C:\\Users\\wu.xia\\Downloads\\julius-drost-oC66vXsqnc8-unsplash.jpg'

    # label_count = detect_labels_local_file(photo)
    # print("Labels detected: " + str(label_count))
    detect_labels_local_file(photo)


if __name__ == "__main__":
    main()
