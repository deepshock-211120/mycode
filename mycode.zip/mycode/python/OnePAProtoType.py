from selenium.webdriver.remote.webelement import WebElement
from datetime import date, timedelta
import time
from selenium.webdriver.support.ui import Select
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium import webdriver
from typing import get_type_hints
from logging import Handler
# package getText


preferred_cc = ["4110ccmcpa-bm", "2400IPOGPA-BM"]
urlbase = "https://www.onepa.gov.sg/facilities/"
# Configs
print(date.today() + timedelta(days=15))
print(date.weekday(date.today()))
# exit()


def check_availability(url):
    # print("hehe"+url)
    driver = webdriver.Chrome()
    driver.get(url)
    # Step 1
    elem1 = driver.find_element_by_name("content_0$tbDatePicker")
    elem1.click()
    elem1.click()
    elem1.click()
    time.sleep(5)
    # Step 2
    elem2 = driver.find_elements_by_xpath(
        "//a[@class='ui-datepicker-next ui-corner-all ui-state-disabled']")
    if len(elem2) != 1:
        elem3 = driver.find_element_by_xpath("//a[@data-handler='next']")
        elem3.click()
        time.sleep(5)

    elem4 = driver.find_elements_by_xpath("//td[@data-handler='selectDay']")
    # print(elem4[-1].text)
    elem4[-1].click()
    time.sleep(5)

    elem5 = driver.find_element_by_name("content_0$tbDatePicker")
    print(elem5.get_attribute('value'))
    elem6 = driver.find_elements_by_xpath("//span[@class='slots normal']")
    intNumOfSlotsAvailable = len(elem6)
    elem7 = driver.find_elements_by_xpath("//span[@class='slots peak']")
    intNumOfSlotsAvailable += len(elem7)

    if intNumOfSlotsAvailable > 0:
        print("There is freeslot at {}! Quickly Book.".format(url))
    else:
        print("There is no freeslot at {}.".format(url))

    time.sleep(5)
    driver.close()


for cc_code in preferred_cc:
    url = urlbase+cc_code
    check_availability(url)

exit()
intNumberOfDaysInAdvance = 16
# 31/01/2021 todo: templatize the url to perform the browser automation
# 04/02/2021 todo: intercept with sleep https://realpython.com/python-sleep/
# 04/02/2021 todo: handle when last book-able date is in next month


# Step 1: access the webpage


# Step 2: There is a notice page upon loading the page. Need to click "OK"
# elem = driver.find_element_by_name("content_0$btnCancel")
# if len(elem) > 0:
#     elem.click()
#     time.sleep(2)

# Step 3: Select the calendar date picker

# print('here')
# Step 4: Choose the last available date


# print(len(elem2))

# print("4")

# print("5")


# select = Select(driver.find_element_by_name('content_0$ddlFacilityLocation'))
# listCCOptions = Select.options
# print(len(listCCOptions))
# print(listCCOptions)
# select.select_by_index(index)
# select.select_by_visible_text("text")

# If the latest "book-able" dates are displayed, then click on it.


# Step 5: Verify if there is any normal slots avaiable


#
#


# Step 3: choose a date

# elem = driver.find_elements_by_xpath("div[@Class='slots']")
# timeslotcount = len(elem)

# elem = driver.find_elements_by_xpath("//span[@class='slots normal']")
# timeslotcount = len(elem)
# print(timeslotcount)

# elem = driver.find_elements_by_xpath("//span[@class='slots booked']")
# timeslotcount = len(elem)
# print(timeslotcount)

# elem = driver.find_elements_by_xpath("//span[@class='slots notAvailable']")
# timeslotcount = len(elem)
# print(timeslotcount)

# elem = driver.find_elements_by_xpath("//span[@class='slots peak']")
# timeslotcount = len(elem)
# print(timeslotcount)

# # elem = driver.find_element_by_class_name("slots booked")

# # subelem = elem[-1].find_element_by_class("ui-state-default")
# # Final Step: wait for 10 seconds before closing the browser
# # time.sleep(2)
# driver.close()
