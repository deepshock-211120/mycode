# msg = "hello world"
# print(msg)
sampledict = {'Level1': [
    {'Key': 'B',
     'Value': 5},
    {'Key': 'A',
     'Value': 7},
    {'Key': 'C',
     'Value': 3},
]}

print(type(sampledict['Level1'][0]))
# print(sampledict['Level1'].sort())
print(sorted(sampledict['Level1'], key=lambda i: i['Value'], reverse=True))
